package com.iptvapp.data

import com.iptvapp.model.Channel
import com.iptvapp.model.SourceType
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object M3UParser {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    /**
     * Descarga y parsea una lista M3U desde cualquier URL:
     * - URL directa:   http://servidor/lista.m3u
     * - Dropbox:       https://www.dropbox.com/s/xxx/lista.m3u?dl=1
     * - Google Drive:  https://drive.google.com/uc?export=download&id=TU_ID
     * - GitHub raw:    https://raw.githubusercontent.com/...
     * - OneDrive:      https://onedrive.live.com/download?...
     */
    fun parse(url: String): List<Channel> {
        val finalUrl = normalizeUrl(url)
        val request = Request.Builder()
            .url(finalUrl)
            .addHeader("User-Agent", "IPTV-TDT/1.0")
            .build()
        val body = client.newCall(request).execute().body?.string() ?: return emptyList()
        return parseContent(body)
    }

    /**
     * Normaliza URLs de Dropbox, Google Drive y OneDrive
     * para forzar descarga directa del fichero
     */
    fun normalizeUrl(url: String): String {
        return when {
            url.contains("dropbox.com") ->
                url.replace("?dl=0", "?dl=1")
                   .replace("www.dropbox.com", "dl.dropboxusercontent.com")

            url.contains("drive.google.com/file/d/") -> {
                val id = url.substringAfter("/d/").substringBefore("/")
                "https://drive.google.com/uc?export=download&id=$id"
            }
            url.contains("drive.google.com/open?id=") -> {
                val id = url.substringAfter("id=")
                "https://drive.google.com/uc?export=download&id=$id"
            }

            url.contains("1drv.ms") || url.contains("onedrive.live.com") ->
                url.replace("redir?", "download?")

            else -> url
        }
    }

    fun parseContent(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()
        var autoNumber = 1

        var i = 0
        while (i < lines.size) {
            val line = lines[i].trim()
            if (line.startsWith("#EXTINF")) {
                val name  = extractAttr(line, "tvg-name") ?: extractDisplayName(line) ?: "Canal $autoNumber"
                val logo  = extractAttr(line, "tvg-logo") ?: ""
                val group = extractAttr(line, "group-title") ?: ""
                val epgId = extractAttr(line, "tvg-id") ?: ""
                val chNum = extractAttr(line, "tvg-chno")?.toIntOrNull() ?: autoNumber

                var j = i + 1
                while (j < lines.size && lines[j].trim().isEmpty()) j++
                val streamUrl = if (j < lines.size) lines[j].trim() else ""

                if (streamUrl.isNotEmpty() && !streamUrl.startsWith("#")) {
                    channels.add(
                        Channel(
                            id        = "m3u_$chNum",
                            name      = name,
                            number    = chNum,
                            streamUrl = streamUrl,
                            logoUrl   = logo,
                            group     = group,
                            source    = SourceType.M3U,
                            epgId     = epgId
                        )
                    )
                    autoNumber++
                    i = j + 1
                    continue
                }
            }
            i++
        }
        return channels
    }

    private fun extractAttr(line: String, attr: String): String? {
        val regex = Regex("""$attr="([^"]*)"")
        return regex.find(line)?.groupValues?.get(1)?.takeIf { it.isNotBlank() }
    }

    private fun extractDisplayName(line: String): String? {
        val idx = line.lastIndexOf(',')
        return if (idx >= 0) line.substring(idx + 1).trim().takeIf { it.isNotBlank() } else null
    }
}
