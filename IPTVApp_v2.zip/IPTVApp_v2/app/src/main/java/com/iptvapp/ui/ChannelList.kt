package com.iptvapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.iptvapp.model.Channel
import com.iptvapp.model.EpgProgram

@Composable
fun ChannelListSidebar(
    channels: List<Channel>,
    currentIndex: Int,
    epg: Map<String, List<EpgProgram>>,
    onChannelSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val listState = rememberLazyListState()

    LaunchedEffect(currentIndex) {
        if (currentIndex >= 0 && currentIndex < channels.size) {
            listState.animateScrollToItem(maxOf(0, currentIndex - 3))
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Fondo semi-transparente
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.6f))
                .clickable { onDismiss() }
        )

        // Panel lateral derecho
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(380.dp)
                .align(Alignment.CenterEnd)
                .background(Color(0xF01A1A2E))
        ) {
            Column {
                // Cabecera
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .background(TDTAccent),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = "  📺  Canales",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }

                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(channels) { index, channel ->
                        val isSelected = index == currentIndex
                        val now = System.currentTimeMillis()
                        val currentProg = epg[channel.epgId]
                            ?.firstOrNull { it.startTime <= now && it.endTime > now }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isSelected) TDTAccent.copy(alpha = 0.3f)
                                    else Color.Transparent
                                )
                                .clickable { onChannelSelect(index); onDismiss() }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Número
                            Text(
                                text = channel.number.toString().padStart(3, ' '),
                                color = if (isSelected) TDTYellow else Color.White.copy(alpha = 0.5f),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(36.dp)
                            )

                            // Logo
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.White.copy(alpha = 0.05f)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (channel.logoUrl.isNotEmpty()) {
                                    AsyncImage(
                                        model = channel.logoUrl,
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Text(
                                        text = channel.name.take(2).uppercase(),
                                        color = Color.White.copy(alpha = 0.4f),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            // Nombre + programa
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = channel.name,
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.85f),
                                    fontSize = 14.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (currentProg != null) {
                                    Text(
                                        text = currentProg.title,
                                        color = Color.White.copy(alpha = 0.45f),
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            // Indicador fuente
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(
                                        when (channel.source.name) { "STALKER" -> Color(0xFF4A148C); "XTREAM" -> Color(0xFF1B5E20); else -> Color(0xFF0D47A1) }
                                        else Color(0xFF0D47A1)
                                    )
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = when (channel.source.name) { "STALKER" -> "STK"; "XTREAM" -> "XTR"; else -> "M3U" },
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 9.sp
                                )
                            }
                        }

                        // Separador
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Color.White.copy(alpha = 0.05f))
                        )
                    }
                }
            }
        }
    }
}
