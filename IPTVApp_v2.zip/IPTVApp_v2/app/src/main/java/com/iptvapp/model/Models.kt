package com.iptvapp.model

data class Channel(
    val id: String,
    val name: String,
    val number: Int,
    val streamUrl: String,
    val logoUrl: String = "",
    val group: String = "",
    val source: SourceType = SourceType.M3U,
    val epgId: String = ""
)

data class EpgProgram(
    val channelId: String,
    val title: String,
    val description: String = "",
    val startTime: Long,
    val endTime: Long
)

enum class SourceType { M3U, STALKER, XTREAM }

data class AppConfig(
    // ─────────────────────────────────────────────────────────────────────────
    // FUENTE 1 — Lista M3U (URL directa, Dropbox, Google Drive, etc.)
    //
    // Dropbox:      cambia ?dl=0 por ?dl=1 al final del enlace
    // Google Drive: usa https://drive.google.com/uc?export=download&id=TU_ID
    // URL normal:   http://servidor/lista.m3u o http://servidor/lista.m3u8
    //
    val m3uUrl: String = "",   // deja vacío si no usas M3U

    // ─────────────────────────────────────────────────────────────────────────
    // FUENTE 2 — Xtream Codes
    //
    // Ejemplo: servidor = "http://s1lc.net:8080"
    //          usuario  = "CesarFigueroa"
    //          password = "UaaC7wSwk3i"
    //
    val xtreamServer: String = "",    // deja vacío si no usas Xtream
    val xtreamUser: String = "",
    val xtreamPassword: String = "",

    // ─────────────────────────────────────────────────────────────────────────
    // FUENTE 3 — Stalker Middleware (MAG, etc.)
    //
    val stalkerPortalUrl: String = "http://saray68.darktv.nl/c",   // deja vacío si no usas Stalker
    val stalkerMac: String = "00:1A:79:6A:A9:D0",

	


    // ─────────────────────────────────────────────────────────────────────────
    // EPG — Guía de programación (opcional, formato XMLTV)
    //
    // También puede ser una URL remota (Dropbox, Drive, servidor propio)
    //
    val epgUrl: String = "",

    // ─────────────────────────────────────────────────────────────────────────
    // OPCIONES
    //
    val mergeAllSources: Boolean = true,
    val removeDuplicates: Boolean = true,
)
