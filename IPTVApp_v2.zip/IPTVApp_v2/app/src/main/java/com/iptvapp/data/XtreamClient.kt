package com.iptvapp.data

import com.iptvapp.model.Channel
import com.iptvapp.model.SourceType
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

/**
 * Cliente Xtream Codes API
 * Obtiene canales en vivo, con logos, grupos y números de canal
 */
object XtreamClient {

    private val client = OkHttpClient()

    data class XtreamConfig(
        val server: String,   // ej: http://miservidor.com:8080
        val user: String,
        val password: String
    )

    /**
     * Carga todos los canales en directo desde la API Xtream Codes
     */
    fun loadChannels(config: XtreamConfig): List<Channel> {
        return try {
            // 1. Verificar credenciales
            if (!authenticate(config)) return emptyList()

            // 2. Obtener categorías para asignar grupos
            val categories = loadCategories(config)

            // 3. Obtener canales en directo
            loadLiveStreams(config, categories)
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Construye la URL M3U de Xtream (útil como alternativa)
     * http://servidor/get.php?username=X&password=Y&type=m3u_plus&output=ts
     */
    fun buildM3UUrl(config: XtreamConfig): String {
        val base = config.server.trimEnd('/')
        return "$base/get.php?username=${config.user}&password=${config.password}&type=m3u_plus&output=ts"
    }

    private fun authenticate(config: XtreamConfig): Boolean {
        return try {
            val base = config.server.trimEnd('/')
            val url = "$base/player_api.php?username=${config.user}&password=${config.password}"
            val response = get(url)
            val json = JSONObject(response)
            // Si existe user_info, las credenciales son válidas
            json.has("user_info")
        } catch (e: Exception) { false }
    }

    private fun loadCategories(config: XtreamConfig): Map<String, String> {
        return try {
            val base = config.server.trimEnd('/')
            val url = "$base/player_api.php?username=${config.user}&password=${config.password}&action=get_live_categories"
            val array = JSONArray(get(url))
            val map = mutableMapOf<String, String>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                map[obj.optString("category_id")] = obj.optString("category_name")
            }
            map
        } catch (e: Exception) { emptyMap() }
    }

    private fun loadLiveStreams(config: XtreamConfig, categories: Map<String, String>): List<Channel> {
        val base = config.server.trimEnd('/')
        val url = "$base/player_api.php?username=${config.user}&password=${config.password}&action=get_live_streams"
        val array = JSONArray(get(url))
        val channels = mutableListOf<Channel>()

        for (i in 0 until array.length()) {
            val ch = array.getJSONObject(i)
            val streamId = ch.optString("stream_id")
            val name = ch.optString("name", "Canal ${i + 1}")
            val num = ch.optInt("num", i + 1)
            val logo = ch.optString("stream_icon", "")
            val catId = ch.optString("category_id", "")
            val group = categories[catId] ?: ""
            val epgId = ch.optString("epg_channel_id", "")

            // URL del stream: formato ts o m3u8
            val streamUrl = "$base/live/${config.user}/${config.password}/$streamId.ts"

            channels.add(
                Channel(
                    id = "xtream_$streamId",
                    name = name,
                    number = num,
                    streamUrl = streamUrl,
                    logoUrl = logo,
                    group = group,
                    source = SourceType.XTREAM,
                    epgId = epgId
                )
            )
        }
        return channels.sortedBy { it.number }
    }

    private fun get(url: String): String {
        val request = Request.Builder()
            .url(url)
            .addHeader("User-Agent", "IPTV-TDT/1.0")
            .build()
        return client.newCall(request).execute().body?.string() ?: "[]"
    }
}
