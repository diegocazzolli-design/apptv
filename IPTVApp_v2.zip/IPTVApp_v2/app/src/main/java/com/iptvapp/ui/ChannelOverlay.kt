package com.iptvapp.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.iptvapp.model.Channel
import com.iptvapp.model.EpgProgram
import java.text.SimpleDateFormat
import java.util.*

val TDTBlue = Color(0xFF0A1628)
val TDTAccent = Color(0xFF2196F3)
val TDTYellow = Color(0xFFFFD600)
val ProgressBg = Color(0xFF1E3A5F)

@Composable
fun ChannelOverlay(
    channel: Channel,
    currentProgram: EpgProgram?,
    nextProgram: EpgProgram?,
    onDismiss: () -> Unit
) {
    // Auto-ocultar tras 5 segundos
    LaunchedEffect(channel.id) {
        kotlinx.coroutines.delay(5000)
        onDismiss()
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.BottomCenter
    ) {
        // Gradiente inferior estilo TDT
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, TDTBlue.copy(alpha = 0.97f)),
                        startY = 0f, endY = Float.POSITIVE_INFINITY
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 48.dp, vertical = 24.dp)
        ) {
            // Fila principal: número, logo, nombre canal + programa
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Número de canal
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TDTAccent),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = channel.number.toString(),
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Logo canal
                if (channel.logoUrl.isNotEmpty()) {
                    AsyncImage(
                        model = channel.logoUrl,
                        contentDescription = channel.name,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.White.copy(alpha = 0.1f))
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    // Nombre del canal
                    Text(
                        text = channel.name,
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    // Programa actual
                    if (currentProgram != null) {
                        Text(
                            text = currentProgram.title,
                            color = TDTYellow,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Hora actual
                val timeStr = remember { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) }
                Text(
                    text = timeStr,
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light
                )
            }

            Spacer(Modifier.height(12.dp))

            // Barra de progreso del programa
            if (currentProgram != null && currentProgram.startTime > 0) {
                ProgramProgressBar(currentProgram)
                Spacer(Modifier.height(8.dp))
            }

            // Siguiente programa
            if (nextProgram != null) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "A continuación:",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 13.sp
                    )
                    Text(
                        text = nextProgram.title,
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    val startStr = SimpleDateFormat("HH:mm", Locale.getDefault())
                        .format(Date(nextProgram.startTime))
                    Text(
                        text = "($startStr)",
                        color = TDTAccent.copy(alpha = 0.8f),
                        fontSize = 13.sp
                    )
                }
            }

            // Badge fuente
            Spacer(Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        when (channel.source.name) { "STALKER" -> Color(0xFF6A1B9A); "XTREAM" -> Color(0xFF2E7D32); else -> Color(0xFF1565C0) }
                        else Color(0xFF1565C0)
                    )
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = channel.source.name,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun ProgramProgressBar(program: EpgProgram) {
    val now = System.currentTimeMillis()
    val total = (program.endTime - program.startTime).coerceAtLeast(1)
    val elapsed = (now - program.startTime).coerceIn(0, total)
    val progress = elapsed.toFloat() / total.toFloat()

    val endStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(program.endTime))

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(program.startTime)),
                color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp
            )
            Text(text = endStr, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(ProgressBg)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(progress)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(TDTAccent)
            )
        }
    }
}
