package com.iptvapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.iptvapp.data.ChannelRepository
import com.iptvapp.model.Channel
import com.iptvapp.model.EpgProgram
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

data class UiState(
    val channels: List<Channel> = emptyList(),
    val currentChannel: Channel? = null,
    val currentIndex: Int = 0,
    val epg: Map<String, List<EpgProgram>> = emptyMap(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val showChannelOverlay: Boolean = false,
    val showEpgGuide: Boolean = false
)

class MainViewModel : ViewModel() {

    private val repository = ChannelRepository()
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    init { loadChannels() }

    private fun loadChannels() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                val channels = repository.loadAll()
                val epg = repository.loadEpg()
                val first = channels.firstOrNull()
                _state.value = _state.value.copy(
                    channels = channels,
                    currentChannel = first,
                    currentIndex = 0,
                    epg = epg,
                    isLoading = false
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = "Error cargando canales: ${e.message}"
                )
            }
        }
    }

    fun selectChannel(index: Int) {
        val channels = _state.value.channels
        if (index < 0 || index >= channels.size) return
        _state.value = _state.value.copy(
            currentChannel = channels[index],
            currentIndex = index,
            showChannelOverlay = true
        )
    }

    fun channelUp() {
        val idx = (_state.value.currentIndex - 1 + _state.value.channels.size) % _state.value.channels.size
        selectChannel(idx)
    }

    fun channelDown() {
        val idx = (_state.value.currentIndex + 1) % _state.value.channels.size
        selectChannel(idx)
    }

    fun toggleOverlay() {
        _state.value = _state.value.copy(showChannelOverlay = !_state.value.showChannelOverlay)
    }

    fun hideOverlay() {
        _state.value = _state.value.copy(showChannelOverlay = false)
    }

    fun toggleEpgGuide() {
        _state.value = _state.value.copy(showEpgGuide = !_state.value.showEpgGuide)
    }

    fun getCurrentProgram(channelId: String): EpgProgram? {
        val now = System.currentTimeMillis()
        return _state.value.epg[channelId]?.firstOrNull { it.startTime <= now && it.endTime > now }
    }

    fun getNextProgram(channelId: String): EpgProgram? {
        val now = System.currentTimeMillis()
        return _state.value.epg[channelId]
            ?.filter { it.startTime > now }
            ?.minByOrNull { it.startTime }
    }
}
