package com.iptvapp.data

import com.iptvapp.model.EpgProgram
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.*

object EpgParser {

    private val dateFormat = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)

    fun fetch(url: String): Map<String, List<EpgProgram>> {
        return try {
            val client = OkHttpClient()
            val request = Request.Builder().url(url).build()
            val body = client.newCall(request).execute().body?.string() ?: return emptyMap()
            parse(body)
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun parse(xml: String): Map<String, List<EpgProgram>> {
        val result = mutableMapOf<String, MutableList<EpgProgram>>()
        try {
            val factory = XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            parser.setInput(StringReader(xml))

            var channelId = ""
            var title = ""
            var description = ""
            var start = 0L
            var stop = 0L
            var inTitle = false
            var inDesc = false

            var eventType = parser.eventType
            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "programme" -> {
                            channelId = parser.getAttributeValue(null, "channel") ?: ""
                            start = parseDate(parser.getAttributeValue(null, "start"))
                            stop = parseDate(parser.getAttributeValue(null, "stop"))
                            title = ""
                            description = ""
                        }
                        "title" -> inTitle = true
                        "desc" -> inDesc = true
                    }
                    XmlPullParser.TEXT -> {
                        if (inTitle) title += parser.text
                        if (inDesc) description += parser.text
                    }
                    XmlPullParser.END_TAG -> when (parser.name) {
                        "programme" -> {
                            if (channelId.isNotEmpty() && title.isNotEmpty()) {
                                result.getOrPut(channelId) { mutableListOf() }.add(
                                    EpgProgram(channelId, title, description, start, stop)
                                )
                            }
                        }
                        "title" -> inTitle = false
                        "desc" -> inDesc = false
                    }
                }
                eventType = parser.next()
            }
        } catch (e: Exception) { /* silencioso */ }
        return result
    }

    private fun parseDate(raw: String?): Long {
        if (raw.isNullOrBlank()) return 0L
        return try { dateFormat.parse(raw.trim())?.time ?: 0L }
        catch (e: Exception) { 0L }
    }
}
