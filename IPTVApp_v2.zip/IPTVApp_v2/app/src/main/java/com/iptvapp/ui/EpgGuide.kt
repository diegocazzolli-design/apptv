package com.iptvapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iptvapp.model.Channel
import com.iptvapp.model.EpgProgram
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun EpgGuide(
    channels: List<Channel>,
    epg: Map<String, List<EpgProgram>>,
    onChannelSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val now = System.currentTimeMillis()
    val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF0101828))
    ) {
        Column {
            // Cabecera
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(TDTBlue),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "  📅  Guía de Programación",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f).padding(horizontal = 16.dp)
                )
                Text(
                    text = timeFmt.format(Date(now)) + "  ✕",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 16.sp,
                    modifier = Modifier
                        .padding(end = 24.dp)
                        .clickable { onDismiss() }
                )
            }

            // Grid EPG
            Row(modifier = Modifier.fillMaxSize()) {
                // Columna fija: canales
                LazyColumn(modifier = Modifier.width(200.dp)) {
                    items(channels.take(50)) { channel ->
                        Box(
                            modifier = Modifier
                                .width(200.dp)
                                .height(60.dp)
                                .background(Color(0xFF0D1B2A))
                                .clickable {
                                    onChannelSelect(channels.indexOf(channel))
                                    onDismiss()
                                },
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = channel.number.toString(),
                                    color = TDTAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(28.dp)
                                )
                                Text(
                                    text = channel.name,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Box(
                                modifier = Modifier.fillMaxWidth().height(1.dp)
                                    .background(Color.White.copy(0.07f)).align(Alignment.BottomCenter)
                            )
                        }
                    }
                }

                // Columna deslizante: programas
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(scrollState)
                ) {
                    items(channels.take(50)) { channel ->
                        val programs = epg[channel.epgId]
                            ?.filter { it.endTime > now - 3600_000 }
                            ?.sortedBy { it.startTime }
                            ?: emptyList()

                        Row(
                            modifier = Modifier
                                .height(60.dp)
                                .padding(vertical = 2.dp)
                        ) {
                            if (programs.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .width(300.dp)
                                        .fillMaxHeight()
                                        .padding(horizontal = 4.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF1A2A3A)),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Text(
                                        text = "  Sin guía disponible",
                                        color = Color.White.copy(alpha = 0.3f),
                                        fontSize = 12.sp
                                    )
                                }
                            } else {
                                programs.forEach { prog ->
                                    val durationMin = ((prog.endTime - prog.startTime) / 60000).coerceIn(15, 240)
                                    val isNow = prog.startTime <= now && prog.endTime > now
                                    Box(
                                        modifier = Modifier
                                            .width((durationMin * 3).dp)
                                            .fillMaxHeight()
                                            .padding(horizontal = 2.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                if (isNow) TDTAccent.copy(alpha = 0.4f)
                                                else Color(0xFF1E2D40)
                                            )
                                            .padding(horizontal = 6.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        Column {
                                            Text(
                                                text = timeFmt.format(Date(prog.startTime)),
                                                color = if (isNow) TDTYellow else Color.White.copy(alpha = 0.5f),
                                                fontSize = 10.sp
                                            )
                                            Text(
                                                text = prog.title,
                                                color = Color.White,
                                                fontSize = 12.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
