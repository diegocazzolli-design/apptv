package com.iptvapp.data

import com.iptvapp.model.Channel
import com.iptvapp.model.SourceType
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Cliente básico para Stalker Middleware / MiniSTB
 * Protocolo: http://portal/stalker_portal/server/load.php
 */
object StalkerClient {

    private val client = OkHttpClient()

    /**
     * 1. Autenticación y obtención de token
     * 2. Carga de lista de canales
     */
    suspend fun loadChannels(portalUrl: String, mac: String): List<Channel> {
        return try {
            val token = authenticate(portalUrl, mac) ?: return emptyList()
            fetchChannels(portalUrl, mac, token)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun authenticate(portalUrl: String, mac: String): String? {
        val url = "$portalUrl/stalker_portal/server/load.php" +
                "?type=stb&action=handshake&prehash=0&token=&JsHttpRequest=1-xml"
        val request = Request.Builder()
            .url(url)
            .addHeader("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C)")
            .addHeader("X-User-Agent", "Model: MAG250; Link: WiFi")
            .addHeader("Cookie", "mac=$mac; stb_lang=es; timezone=Europe/Madrid")
            .build()

        val body = client.newCall(request).execute().body?.string() ?: return null
        return try {
            JSONObject(body).getJSONObject("js").getString("token")
        } catch (e: Exception) { null }
    }

    private fun fetchChannels(portalUrl: String, mac: String, token: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        var page = 0
        val pageSize = 14

        while (true) {
            val url = "$portalUrl/stalker_portal/server/load.php" +
                    "?type=itv&action=get_all_channels&force_ch_link_check=&fav=0" +
                    "&sortby=number&hd=0&p=${page + 1}&JsHttpRequest=1-xml"

            val request = Request.Builder()
                .url(url)
                .addHeader("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C)")
                .addHeader("X-User-Agent", "Model: MAG250; Link: WiFi")
                .addHeader("Cookie", "mac=$mac; stb_lang=es; timezone=Europe/Madrid")
                .addHeader("Authorization", "Bearer $token")
                .build()

            val body = client.newCall(request).execute().body?.string() ?: break

            val js = try { JSONObject(body).getJSONObject("js") } catch (e: Exception) { break }
            val data = js.optJSONArray("data") ?: break
            if (data.length() == 0) break

            for (i in 0 until data.length()) {
                val ch = data.getJSONObject(i)
                val id = ch.optString("id")
                val name = ch.optString("name", "Canal")
                val num = ch.optInt("number", channels.size + 1)
                val logo = ch.optString("logo", "")
                val cmd = ch.optString("cmd", "")

                // Resolver la URL de stream real
                val streamUrl = resolveStreamUrl(portalUrl, mac, token, cmd)
                if (streamUrl.isNotEmpty()) {
                    channels.add(
                        Channel(
                            id = "stk_$id",
                            name = name,
                            number = num,
                            streamUrl = streamUrl,
                            logoUrl = logo,
                            source = SourceType.STALKER
                        )
                    )
                }
            }

            val total = js.optInt("total_items", 0)
            if (channels.size >= total) break
            page++
        }
        return channels
    }

    private fun resolveStreamUrl(portalUrl: String, mac: String, token: String, cmd: String): String {
        return try {
            val url = "$portalUrl/stalker_portal/server/load.php" +
                    "?type=itv&action=create_link&cmd=${cmd}&series=0&forced_storage=false" +
                    "&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml"

            val request = Request.Builder()
                .url(url)
                .addHeader("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C)")
                .addHeader("Cookie", "mac=$mac; stb_lang=es; timezone=Europe/Madrid")
                .addHeader("Authorization", "Bearer $token")
                .build()

            val body = client.newCall(request).execute().body?.string() ?: return ""
            JSONObject(body).getJSONObject("js").optString("cmd", "")
                .removePrefix("ffmpeg ")
                .trim()
        } catch (e: Exception) { "" }
    }
}
