package com.iptvapp.data

import com.iptvapp.model.AppConfig
import com.iptvapp.model.Channel
import com.iptvapp.model.EpgProgram
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext

class ChannelRepository(private val config: AppConfig = AppConfig()) {

    suspend fun loadAll(): List<Channel> = withContext(Dispatchers.IO) {
        // Lanzar las 3 fuentes en paralelo
        val m3uDeferred     = async { loadM3U() }
        val xtreamDeferred  = async { loadXtream() }
        val stalkerDeferred = async { loadStalker() }

        val m3u     = m3uDeferred.await()
        val xtream  = xtreamDeferred.await()
        val stalker = stalkerDeferred.await()

        val combined = if (config.mergeAllSources) {
            (xtream + m3u + stalker)   // Xtream primero (suele tener mejor numeración)
        } else {
            // Solo la primera fuente disponible
            when {
                xtream.isNotEmpty()  -> xtream
                m3u.isNotEmpty()     -> m3u
                stalker.isNotEmpty() -> stalker
                else                 -> emptyList()
            }
        }

        val result = if (config.removeDuplicates) {
            combined.distinctBy { it.name.lowercase().trim() }
        } else combined

        result.sortedBy { it.number }
    }

    suspend fun loadEpg(): Map<String, List<EpgProgram>> = withContext(Dispatchers.IO) {
        if (config.epgUrl.isBlank()) return@withContext emptyMap()
        // El EPG también puede estar en Dropbox/Drive — usa el mismo normalizador
        val normalizedUrl = M3UParser.normalizeUrl(config.epgUrl)
        EpgParser.fetch(normalizedUrl)
    }

    private fun loadM3U(): List<Channel> {
        if (config.m3uUrl.isBlank()) return emptyList()
        return try { M3UParser.parse(config.m3uUrl) }
        catch (e: Exception) { emptyList() }
    }

    private fun loadXtream(): List<Channel> {
        if (config.xtreamServer.isBlank() || config.xtreamUser.isBlank()) return emptyList()
        return try {
            XtreamClient.loadChannels(
                XtreamClient.XtreamConfig(
                    server   = config.xtreamServer,
                    user     = config.xtreamUser,
                    password = config.xtreamPassword
                )
            )
        } catch (e: Exception) { emptyList() }
    }

    private suspend fun loadStalker(): List<Channel> {
        if (config.stalkerPortalUrl.isBlank()) return emptyList()
        return try {
            StalkerClient.loadChannels(config.stalkerPortalUrl, config.stalkerMac)
        } catch (e: Exception) { emptyList() }
    }
}
