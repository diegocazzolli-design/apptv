package com.iptvapp.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.iptvapp.MainViewModel
import com.iptvapp.player.VideoPlayer

@Composable
fun MainScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.key) {
                        Key.DirectionUp, Key.ChannelUp -> { viewModel.channelUp(); true }
                        Key.DirectionDown, Key.ChannelDown -> { viewModel.channelDown(); true }
                        Key.Enter, Key.DirectionCenter -> { viewModel.toggleOverlay(); true }
                        Key.Menu, Key.DirectionRight -> { viewModel.toggleEpgGuide(); true }
                        Key.Back, Key.Escape -> {
                            when {
                                state.showEpgGuide -> { viewModel.toggleEpgGuide(); true }
                                state.showChannelOverlay -> { viewModel.hideOverlay(); true }
                                else -> false
                            }
                        }
                        else -> false
                    }
                } else false
            }
    ) {
        // ── LOADING ──────────────────────────────────────────────────────────
        if (state.isLoading) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = TDTAccent, modifier = Modifier.size(56.dp))
                Spacer(Modifier.height(20.dp))
                Text("Cargando canales…", color = Color.White.copy(alpha = 0.7f), fontSize = 18.sp)
            }
            return@Box
        }

        // ── ERROR ─────────────────────────────────────────────────────────────
        if (state.error != null) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("⚠️", fontSize = 48.sp)
                Spacer(Modifier.height(12.dp))
                Text(state.error ?: "", color = Color.White, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Verifica la URL en AppConfig.kt",
                    color = TDTAccent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            return@Box
        }

        // ── NO CHANNELS ───────────────────────────────────────────────────────
        if (state.channels.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("📡", fontSize = 64.sp)
                Spacer(Modifier.height(16.dp))
                Text("No se encontraron canales", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Edita las URLs en Models.kt → AppConfig", color = Color.White.copy(alpha = 0.5f), fontSize = 15.sp)
            }
            return@Box
        }

        // ── VIDEO PLAYER ──────────────────────────────────────────────────────
        state.currentChannel?.let { channel ->
            VideoPlayer(
                streamUrl = channel.streamUrl,
                modifier = Modifier.fillMaxSize()
            )

            // ── OVERLAY INFO (estilo TDT) ─────────────────────────────────────
            AnimatedVisibility(
                visible = state.showChannelOverlay,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                ChannelOverlay(
                    channel = channel,
                    currentProgram = viewModel.getCurrentProgram(channel.epgId),
                    nextProgram = viewModel.getNextProgram(channel.epgId),
                    onDismiss = { viewModel.hideOverlay() }
                )
            }
        }

        // ── CHANNEL LIST SIDEBAR ──────────────────────────────────────────────
        // Se activa con UP/DOWN cuando no hay overlay, o manualmente
        AnimatedVisibility(
            visible = state.showChannelOverlay && !state.showEpgGuide,
            enter = slideInHorizontally(initialOffsetX = { it }),
            exit = slideOutHorizontally(targetOffsetX = { it })
        ) {
            ChannelListSidebar(
                channels = state.channels,
                currentIndex = state.currentIndex,
                epg = state.epg,
                onChannelSelect = { viewModel.selectChannel(it) },
                onDismiss = { viewModel.hideOverlay() }
            )
        }

        // ── EPG GUIDE ─────────────────────────────────────────────────────────
        AnimatedVisibility(
            visible = state.showEpgGuide,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically()
        ) {
            EpgGuide(
                channels = state.channels,
                epg = state.epg,
                onChannelSelect = { viewModel.selectChannel(it) },
                onDismiss = { viewModel.toggleEpgGuide() }
            )
        }

        // ── AYUDA TECLAS (esquina superior derecha) ───────────────────────────
        if (!state.showChannelOverlay && !state.showEpgGuide) {
            Column(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(24.dp),
                horizontalAlignment = Alignment.End
            ) {
                KeyHint("↑↓", "Cambiar canal")
                KeyHint("OK", "Info canal")
                KeyHint("MENÚ", "Guía EPG")
            }
        }
    }
}

@Composable
private fun KeyHint(key: String, label: String) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .background(Color.White.copy(alpha = 0.15f))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(text = key, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Text(text = label, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
    }
}
